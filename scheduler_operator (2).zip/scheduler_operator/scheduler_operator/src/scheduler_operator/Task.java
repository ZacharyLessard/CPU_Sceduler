/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduler_operator;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author zachary
 */
public class Task {
    public long timeSlice;
    private long timestamp;
    private long timeRemaining;
    public long completedTime;
    public int PID;
    public boolean finished = false;
    
    public Task(long timeSlice, long completedTime, int PID) {
        // set all the variables 
       // System.out.println(PID);
        this.PID = PID;
        this.timeSlice = timeSlice;
        this.completedTime = completedTime;
        timeRemaining = completedTime;
        PID = ThreadLocalRandom.current().nextInt(1,10000);
    }
    
    /**
     * Run the task
     * @return completed or not
     */
    public boolean run() {
        timestamp = System.currentTimeMillis();
        while (true) {
            long deltaTime = System.currentTimeMillis() - timestamp;
            if (deltaTime >= timeSlice) {
                timeRemaining -= deltaTime;
                finished = false;
                return false;
            } else if (deltaTime >= timeRemaining) {
                timeRemaining -= deltaTime;
                finished = true;
                return true;
            }
        }
    }
    
}
