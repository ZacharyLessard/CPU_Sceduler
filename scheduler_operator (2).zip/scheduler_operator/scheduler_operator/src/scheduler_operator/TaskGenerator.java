/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduler_operator;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author zachary
 */
public class TaskGenerator {
   public ArrayList[] createArray() {
    int IDnum = 1;
    ArrayList[] Band_Array = new ArrayList[11];
    for (int i = 0; i < 11; i++) {
        ArrayList band = new ArrayList();
        // create a task
        int taskAmount = ThreadLocalRandom.current().nextInt(1,10);
        for(int j = 0; j < taskAmount; j++){
        long size = ThreadLocalRandom.current().nextInt(10,801);
   
        long slice = 0;
        if (i < 8) {
            slice = 200;
        } else {
            slice = 10;
        }
        Task task = new Task(slice, size , IDnum);
      
        band.add(task);
        IDnum = IDnum + 1;
       // System.out.println(number);
        }
        // give it a time slice based on i - i being priority
        // random number of tasks 1-10
        // for each create a task and add it to the band
        Band_Array[i] = band;
    }
    
    return Band_Array;
}
}

