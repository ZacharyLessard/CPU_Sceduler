/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduler_operator;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author zachary
 */
public class Scheduler_operator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      
     
        TaskGenerator tg = new TaskGenerator();
        ArrayList[] list = tg.createArray();
        // take start time here
        long starttime = System.currentTimeMillis();
        for (int o = 0; o < 11; o++) {
        ArrayList ba = list[o];
        boolean Program_Running = true;
       // take priority band time here
       long PRTY_Time = System.currentTimeMillis();
        while (Program_Running) {
            Program_Running = false;
        for (int y = 0; y < ba.size(); y++) {
            Task t = (Task) ba.get(y);
            if (!t.finished) {
                boolean done = t.run();
                if (done) {
                   
                    
                    // subtract time - current time
                    long ptime = System.currentTimeMillis() - PRTY_Time;
                    long ctime = System.currentTimeMillis() - starttime;
                    // subtract priority time - current time;
                   System.out.println("PID: " + t.PID + " Priority: " + o + " Time:" + t.completedTime + " Slice:" + t.timeSlice + "priority time: " + ptime + " total completion time: "+ ctime); 
                } 
                if (!done) {
                    Program_Running = true;
                    // if it doesnt complete
                    //System.out.println("didnt complete" + o + "-" + y); 
                }
            }
        }
        }
       }
    }
}
   
      

       
       
        
 

